# Meter Reader — Android starter

This first version provides:

- Rear-camera live preview
- Meter alignment guide
- Capture image
- On-device ML Kit OCR
- Conservative numeric extraction for meter readings
- Manual correction field

## Open in Android Studio

Open the `MeterReaderApp` folder in Android Studio and let Gradle sync.

Requirements:
- Android Studio with Android Gradle Plugin 8.13+ support
- JDK 17+
- Android SDK 36
- A physical Android phone is recommended for camera testing

The app requests camera permission at runtime.

## OCR note

Generic OCR can misread reflective, seven-segment, mechanical, or low-contrast meter displays. The next improvement should be a meter-display crop/deskew step plus digit-specific recognition and confidence checks.
