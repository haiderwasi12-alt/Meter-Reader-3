package com.example.meterreader

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.meterreader.databinding.ActivityMainBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else binding.statusText.text = "Camera permission is required to read the meter."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.captureButton.setOnClickListener {
            captureAndRead()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = binding.previewView.surfaceProvider
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val selector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, selector, preview, imageCapture
                )
            } catch (e: Exception) {
                binding.statusText.text = "Unable to start camera: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureAndRead() {
        val capture = imageCapture ?: return

        binding.captureButton.isEnabled = false
        binding.statusText.text = "Reading meter..."

        capture.takePicture(
            cameraExecutor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(imageProxy: androidx.camera.core.ImageProxy) {
                    val mediaImage = imageProxy.image
                    if (mediaImage == null) {
                        imageProxy.close()
                        runOnUiThread {
                            binding.captureButton.isEnabled = true
                            binding.statusText.text = "Could not capture image."
                        }
                        return
                    }

                    val image = InputImage.fromMediaImage(
                        mediaImage,
                        imageProxy.imageInfo.rotationDegrees
                    )

                    val recognizer = TextRecognition.getClient(
                        TextRecognizerOptions.DEFAULT_OPTIONS
                    )

                    recognizer.process(image)
                        .addOnSuccessListener { result ->
                            val digits = extractMeterDigits(result.text)

                            runOnUiThread {
                                if (digits.isNotEmpty()) {
                                    binding.readingEditText.setText(digits)
                                    binding.statusText.text =
                                        "Reading detected. Check it and correct if needed."
                                } else {
                                    binding.statusText.text =
                                        "No meter digits detected. Move closer, improve lighting, and try again."
                                }
                                binding.captureButton.isEnabled = true
                            }
                        }
                        .addOnFailureListener { error ->
                            runOnUiThread {
                                binding.statusText.text =
                                    "OCR failed: ${error.localizedMessage ?: "try again"}"
                                binding.captureButton.isEnabled = true
                            }
                        }
                        .addOnCompleteListener {
                            imageProxy.close()
                            recognizer.close()
                        }
                }

                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread {
                        binding.captureButton.isEnabled = true
                        binding.statusText.text =
                            "Capture failed: ${exception.message ?: "try again"}"
                    }
                }
            }
        )
    }

    /**
     * Meter OCR is intentionally conservative:
     * - Convert common OCR letter mistakes into digits.
     * - Keep only numeric characters.
     * - Select the longest numeric run, which is usually the meter register.
     */
    private fun extractMeterDigits(rawText: String): String {
        val normalized = rawText
            .uppercase()
            .replace('O', '0')
            .replace('I', '1')
            .replace('L', '1')
            .replace('S', '5')
            .replace('B', '8')
            .replace('G', '6')

        val candidates = normalized
            .split(Regex("[^0-9]+"))
            .filter { it.length >= 2 }

        return candidates.maxByOrNull { it.length } ?: ""
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
