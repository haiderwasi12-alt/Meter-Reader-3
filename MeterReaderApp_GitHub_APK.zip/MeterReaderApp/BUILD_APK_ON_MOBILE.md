# Mobile se APK banane ka tareeqa

## 1. GitHub account
Mobile browser me github.com khol kar login karein.

## 2. New repository
"+" -> "New repository"
Name: MeterReader
Repository ko Public rakhna sabse aasaan hai.
"Create repository" dabayein.

## 3. Project upload
Repository page par:
"Add file" -> "Upload files"

Is ZIP ko pehle extract karein, phir **andar ke tamam files/folders** upload karein.
Important: `.github/workflows/build-apk.yml` bhi upload hona chahiye.

Commit changes karein.

## 4. APK build
Repository me "Actions" tab kholein.
"Build Meter Reader APK" workflow select karein.
Agar workflow automatically run na ho to "Run workflow" dabayein.

Build complete hone tak wait karein.

## 5. APK download
Completed workflow kholein.
Neeche "Artifacts" me:
MeterReader-APK

is ZIP ko download karein.
ZIP ke andar `app-debug.apk` hogi.

APK ko phone me install karne ke liye Android agar permission maange to
"Install unknown apps" ki permission browser/files app ko deni pad sakti hai.

## Important
Ye debug APK hai, testing ke liye hai. Play Store ke liye baad me signed release build banayenge.
